﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labelbarvy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int x = 10;
       public int y = 10;
        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void button1_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    y += 10;
                    panel1.Location = new Point(x, y);
                    break;
                case Keys.Right:
                    y -= 10;
                    panel1.Location = new Point(x, y);
                    break;
                case Keys.Left:
                    x -= 10;
                    panel1.Location = new Point(x, y);
                    break;
                case Keys.Down:
                    x += 10;
                    panel1.Location = new Point(x, y);
                    break;
            }

        }
    }
}
